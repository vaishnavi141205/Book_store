# HTML-project
Bookflix and Chill
This project consists of an online site where you can view diffrent books with their price and gives you the opportunity to sign in, buy them, read reviews of other clients etc. Javascript and css are used to make this page more interesting through animations, font type, different colors, etc.
